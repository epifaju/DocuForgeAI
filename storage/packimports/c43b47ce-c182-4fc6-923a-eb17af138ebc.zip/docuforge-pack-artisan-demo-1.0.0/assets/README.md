Répertoire réservé aux ressources graphiques du pack.
