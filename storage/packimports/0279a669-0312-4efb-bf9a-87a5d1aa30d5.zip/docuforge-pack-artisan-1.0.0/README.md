# Pack Artisan — DocuForge AI

Version 1.0.0 — DBPF-1

Pack de 10 modèles métier pour artisans et petites entreprises. Tous les exemples sont fictifs.

## Modèles
1. Devis
2. Facture
3. Bon d’intervention
4. Bon de livraison
5. Attestation de fin de travaux
6. Rapport d’intervention
7. Mise en demeure simple
8. Courrier de retard chantier
9. Fiche client
10. Procès-verbal de réception

## Installation
Administration > Packs métier > Importer, sélectionner le ZIP, valider le rapport puis installer.

## Important
Les modèles doivent être adaptés à l’activité, au statut de l’entreprise, au client et aux obligations applicables. Les modèles de courrier ou de réception ne constituent pas un conseil juridique.
