Sources de périmètre : mne.gw — Atos Consulares Praticados ; Embaixada da Guiné-Bissau em Portugal — Secção Consular / Pedidos Consulares.
