# Pack Consulat de Guinée-Bissau — Actes et attestations

Version 0.1.0 — DBPF-1 — fr-FR.

Ce pack contient 33 modèles documentaires de démonstration harmonisés sur la présentation du modèle DocuForge « Extrait d’acte de naissance — filiation complète ».

Tous les modèles portent la mention **MODÈLE DÉMONSTRATIF — SANS VALEUR LÉGALE**. Ils sont destinés au développement, aux tests et au paramétrage de DocuForge AI. Ils ne reproduisent pas les éléments de sécurité d’un passeport, visa, titre de voyage ou acte authentique.

Le périmètre s’appuie sur la liste publique des actes consulaires du Ministère des Affaires étrangères de la Guinée-Bissau et sur les services publiés par des représentations consulaires. Les intitulés complémentaires (par ex. concordance/coutume) doivent être validés par le poste consulaire avant usage institutionnel.
