# Changelog

## 1.0.0
- Première version DBPF-1.
- 10 modèles DOCX.
- Métadonnées et variables.
- 7 prompts IA.
- Exemples JSON et CSV.
- Previews PNG.
