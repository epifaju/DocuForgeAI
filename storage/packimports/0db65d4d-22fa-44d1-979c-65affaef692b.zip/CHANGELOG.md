# Changelog

## 1.0.0
- Version initiale de demonstration (3 templates, 2 prompts, samples JSON/CSV, previews).
