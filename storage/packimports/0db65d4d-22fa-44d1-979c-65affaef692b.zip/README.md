# Pack Artisan Demo

Pack officiel de demonstration DocuForge (`com.docuforge.pack.artisan-demo`).

Contenu fictif uniquement — aucune donnee personnelle reelle.
