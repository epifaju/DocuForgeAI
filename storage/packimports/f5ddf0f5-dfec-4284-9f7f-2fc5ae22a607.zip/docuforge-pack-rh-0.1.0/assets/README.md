# Assets

Répertoire réservé aux futurs éléments graphiques du Pack RH.
