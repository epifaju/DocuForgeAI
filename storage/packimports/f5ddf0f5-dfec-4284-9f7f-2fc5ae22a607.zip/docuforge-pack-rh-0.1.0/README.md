# DocuForge AI — Pack RH

Version : **0.1.0**  
Format : **DBPF-1**  
Pack ID : `com.docuforge.pack.rh`

Pack de 16 modèles RH génériques en français, conçu pour DocuForge AI.

## Contenu

- Promesse d'embauche (`RH_PROMESSE_EMBAUCHE`)
- Attestation employeur (`RH_ATTESTATION_EMPLOYEUR`)
- Attestation de travail (`RH_ATTESTATION_TRAVAIL`)
- Lettre de bienvenue (`RH_LETTRE_BIENVENUE`)
- Convocation à un entretien (`RH_CONVOCATION_ENTRETIEN`)
- Compte rendu d'entretien (`RH_COMPTE_RENDU_ENTRETIEN`)
- Demande de congés (`RH_DEMANDE_CONGES`)
- Réponse à demande de congés (`RH_REPONSE_CONGES`)
- Fiche d’intégration salarié (`RH_FICHE_INTEGRATION`)
- Fiche de poste (`RH_FICHE_POSTE`)
- Compte rendu annuel (`RH_COMPTE_RENDU_ANNUEL`)
- Note interne (`RH_NOTE_INTERNE`)
- Courrier de changement d'horaires (`RH_CHANGEMENT_HORAIRES`)
- Attestation de formation (`RH_ATTESTATION_FORMATION`)
- Checklist onboarding (`RH_CHECKLIST_ONBOARDING`)
- Checklist offboarding (`RH_CHECKLIST_OFFBOARDING`)

## Avertissement

Les modèles sont des bases documentaires à personnaliser. Les documents ayant des effets RH, contractuels ou juridiques doivent être vérifiés selon la situation, les accords applicables et les règles en vigueur. Le pack ne constitue pas un conseil juridique.

Les données d'exemple sont fictives et utilisent le domaine réservé `example.invalid`.

## Intégration

Importer l'archive ZIP depuis **Administration > Packs métier > Importer**. DocuForge doit valider le manifeste, les checksums, les DOCX, les placeholders et les métadonnées avant installation.
