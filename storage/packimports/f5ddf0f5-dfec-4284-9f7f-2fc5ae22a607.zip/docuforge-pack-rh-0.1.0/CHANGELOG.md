# Changelog — Pack RH

## 0.1.0 — 2026-09-06

- Première version préliminaire.
- 16 modèles RH.
- Métadonnées DBPF-TEMPLATE-1.
- 8 prompts IA.
- Jeux de données JSON fictifs et CSV batch.
- Previews et checksums.
